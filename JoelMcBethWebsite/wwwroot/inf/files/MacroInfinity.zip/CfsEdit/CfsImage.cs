using System;
using System.Collections.Generic;
using System.Text;

using System.Drawing;

namespace JoelMcbeth.CfsEdit
{
    public class CfsImage
    {
        public CfsImage()
        {
        }

    }
}
